# Practice design and feedback

## Extract instructor patterns

Match analysis depth to the request. A concept question needs its relevant item and teaching basis, not an inventory of every paper. At intake, summarize only formats directly observed in the review; inspect further items as practice requires. Before a full mock exam, expand this into sufficient topic/format coverage for the blueprint and check each generated item.

For each accessible paper/review, record its identity and whether it is an exam, review, or answer key. Describe formats and reasoning operations: tracing, constructing code, selecting a graph, interpreting data, explaining a mechanism, comparing models, or doing calculations. Use question locators to support claims.

Identify distractor mechanisms, such as confusing an output with its input object, reversing a logical implication, omitting a boundary condition, or mixing related quantities. Also record assumptions used by the course. Two near-identical review sheets are not two independent samples of exam tendencies; make this limitation explicit. Missing pages and unreadable diagrams limit frequency counts.

## Blueprint and item metadata

For a mock exam, match known formats, approximate reasoning depth, and confirmed topic breadth. If timing is unknown, give an estimated practice time and label it as an estimate. Targeted drills may deliberately emphasize one weakness. Do not claim a generated paper predicts the exam.

Default mock-exam delivery to an HTML exam worksheet using [mock-exam-layout.md](mock-exam-layout.md), with the checked key separate. This applies even when the student simply says "Make a mock exam." Explicit format requests override it; ordinary question practice may remain in chat.

Keep a small blueprint in the solution file:

| Item | Topic ID | Task/format | Scope/style basis | Personal target | Answer evidence |
|---|---|---|---|---|---|

Separate scope/style provenance from authorship: newly generated items are original synthetic practice, not instructor questions. Missing historical papers permit course-scoped practice but not claims of instructor-style matching.

## Design and check questions

- Make each item answerable from the provided information and approved concepts. State necessary assumptions, variable meanings, units, and data.
- Prefer distractors that reflect an identifiable reasoning error. For multi-select, ensure each option has an independent, unambiguous truth value; explain each in the key.
- Use fresh situations and altered reasoning demands. New names alone do not create a transfer task. Keep prerequisite methods inside scope.
- Check the expected answer first. Compare every option to it. For code, distinguish compilation errors, runtime errors, printed output, returned values, and changes to objects.
- When a runnable environment exists, use controlled synthetic snippets/data to check outputs. Note runtime/version where relevant. Execution verifies that snippet under those conditions, not every claim of asymptotic complexity.
- When execution is unavailable, retain a manual trace/derivation and label it unexecuted. Fix or omit items whose correctness remains materially unresolved.
- If an item depends on a graph, supply a legible graph or a self-contained table plus a suitable rewritten question. Do not refer to a graph the student cannot see.

## Mistake review and variants

For "review my mistakes," use reviewed record evidence and the current conversation to select a small set, prioritizing repeated supported errors, foundational dependencies, and unresolved rechecks. Self-reports may identify targets but remain labelled until the actual work is reviewed. If the original question/key is unavailable, give source-grounded concept practice with that limit rather than reconstruct a supposedly exact mistake.

For each target, identify the error mechanism and choose the next task: a same-structure retry, a new setting requiring the same principle, or a changed condition requiring the student to decide whether the method still applies. State the target and what changed in the separate key. Changing numbers alone practices execution; a transfer task changes context or reasoning demands. Keep variants within supplied scope and check the key before delivery.

Offer a short recheck sequence suited to the exam timeline: correction and explanation, later unaided application, then a distinct-context recheck. Record a retry as a new attempt only when actually attempted, retain prior answer exposure, and distinguish assisted correction, unaided original-question retry, and independent transfer. Update priority after improvement or recurrence; avoid claiming mastery from recognition. Suggested recheck dates are a study plan, not scheduled notifications.

## Domain adaptations

### Programming

Track initial state -> reference/object relationships -> loop/branch changes -> final printed/returned expression. Use small traces and counterexamples. For runtime, define input sizes, distinguish one operation from amortized/total work, and state course simplifications separately from literal language/library costs. Do not assume that a compiler run establishes Big O.

### Statistics and data analysis

Track unit of observation, variable types, grouping state, row/column counts, denominator, missing-value policy, and whether a result was assigned back to the original object. Check graph choice against variables and analytic purpose. Interpret distributions using appropriate features; distinguish association from causal claims. Match the allowed course packages and syntax.

### Astronomy and other conceptual sciences

Distinguish related concepts and the physical mechanism connecting them. Use comparison questions, diagrams when available, limiting cases, and qualitative predictions. Keep mathematical computation out of a concepts-only request. If formulas are included, use the instructor's conventions and explain units and assumptions.

### Humanities and interpretive writing

Choose tasks from the course's actual assessment: factual/concept recall, contextual interpretation of texts or sources, comparison, or argument construction. Use supplied passages and page/section locators; distinguish an author's claim, a source's perspective, and the student's interpretation. Match instructor rubrics when available.

Assess factual accuracy separately from interpretation. For interpretive responses, evaluate whether the answer addresses the prompt, states a defensible claim, selects relevant evidence, explains the inference, and handles context or counterarguments when required. Accept different interpretations supported by the supplied material; a model response is one reasoned example, not the sole valid wording or conclusion. Without a rubric, keep judgments qualitative or label requested scores provisional.

Record specific repairable issues such as an unsupported claim, anachronism, misread passage, missing comparison, or gap between evidence and conclusion. Preserve the student's original claim/evidence/reasoning, distinguish factual error from an arguable reading, and ask for a targeted revision or application to a different supplied passage. Guides may pair short original and revised excerpts with revision reasons. Generated practice passages must be labelled synthetic and must not be attributed to a real author or substituted for authentic course evidence.

## Feedback and scoring

Compare the student's answer to the exact prompt before diagnosing. Show the first error, its consequence, and the corrective rule. A self-report of missed question numbers without the paper or answer key is a reported difficulty, not a verified diagnosis. Ask for the relevant item or explain a general concept with that limitation.

Without a supplied rubric, use correct / partially complete / incorrect / unresolved / unattempted. If the student requests numerical grading, explicitly state provisional scoring rules first and distinguish them from instructor rules. Handle equivalent code, alternative derivations, and justified interpretations fairly.

Offer a short follow-up that changes the situation or asks for reasoning, rather than requesting recall of the just-displayed answer. Update the record using the assistance level and result. Keep explanations proportionate: one straightforward error may need only a short paragraph, while a multi-step trace can warrant a table.
